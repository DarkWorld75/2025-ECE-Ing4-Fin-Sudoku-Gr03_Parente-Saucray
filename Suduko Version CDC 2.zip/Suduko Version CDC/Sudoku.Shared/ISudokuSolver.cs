﻿namespace Sudoku.Shared
{
    public interface ISudokuSolver
    {
        SudokuGrid Solve(SudokuGrid grid);
    }
}

